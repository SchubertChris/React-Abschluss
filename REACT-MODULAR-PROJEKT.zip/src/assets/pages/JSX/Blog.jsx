import React from 'react';
import '../styles/Blog.scss';

export default function Blog() {
  return (
    <div className="blog-container">
      <p>
       &mdash; Flashed? Lies dich rein, hier gehts rund &mdash;
        <span className="animated-text">Frontend Development</span>
        &mdash; in Meisterleistung &mdash;
      </p>
    </div>

  );
}
