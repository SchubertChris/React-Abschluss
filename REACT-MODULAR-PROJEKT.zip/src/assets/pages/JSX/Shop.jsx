export default function Shop() { return <h1>Shop</h1>; }
