export default function ShippingReturns() { return <h1>Shipping & Returns</h1>; }
