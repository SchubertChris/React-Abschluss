export default function Offers() { return <h1>Offers</h1>; }
